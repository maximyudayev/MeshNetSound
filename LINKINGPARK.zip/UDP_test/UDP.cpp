#include "UDP.h"


void startAdvertiser() {
	//create a new Service Advertiser, servicename should be string

	WiFiDirectServiceAdvertiser advertiser = WiFiDirectServiceAdvertiser(L"test");

	/*
	//register for session requests from Seeker, TODO: handle event ??
	//tbh dont give a fuck about accepting those bad bois, auto accept all the way babyyyyy
	Advertiser.SessionRequested += OnSessionrequested;
	*/

	//auto accept all session requests from seekers
	advertiser.AutoAcceptSession(true);

	//start the advertiser
	advertiser.Start();
}