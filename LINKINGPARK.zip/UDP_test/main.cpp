#include "UDP.h"


int main(void) {
	startAdvertiser();
	return 0;
}
