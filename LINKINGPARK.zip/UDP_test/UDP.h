#include <winRT/Windows.Devices.WifiDirect.Services.h>




using namespace winrt::Windows::Devices::WiFiDirect::Services;
//using namespace Windows::Devices::WiFiDirect::Services;


void startAdvertiser();

